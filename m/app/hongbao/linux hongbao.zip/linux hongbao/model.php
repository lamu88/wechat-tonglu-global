<?php
class HongbaoModel extends Model{

}
?>